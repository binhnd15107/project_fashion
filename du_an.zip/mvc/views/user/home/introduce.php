<div class="content">
            <h2 class="title-abaut">

                Giới thiệu | Thời trang K&K Fashion
                <span class="hyphen-title"></span>
                Về chúng tôi
            </h2>
            <div class="row">
                <div class="menu-rotate">
                    <a href="">LOOKBOOK</a>
                    <span></span>
                </div>
                <div class="doinet">
                    <h4>ĐÔI NÉT</h4>

                </div>
                <div class="img_intro">
                    <a href=""><img style="height: 600px;width: 900px;" src=".././public/assets/img/about-us.jpg" alt=""></a>
                    <P>Được thành lập từ năm 2010, kể từ ngày xuất hiện trên thị trường, K&K Fashion đã trở thành một
                        thương hiệu thời trang công sở được các quý cô văn phòng trên toàn quốc ưa chuộng, bởi những
                        thiết kế mang tính ứng dụng cao, vừa lịch sự nơi công sở vừa đáng yêu để dạo phố.</P>
                    <div class="products">
                        <h3>VỀ SẢN PHẨM</h3>
                        <P>K&K Fashion mang đến khách hàng các sản phẩm được cắt cúp tinh tế, phối màu độc đáo, sử dụng
                            chất liệu cao cấp, cùng kỹ thuật cắt may cầu kỳ, xử lý phom dáng công phu giúp tôn lên được
                            những đường cong quyến rũ của người phụ nữ.

                            Việc thường xuyên cập nhật sản phẩm mới hàng tuần giúp cho khách hàng có nhiều sự lựa chọn
                            những bộ trang phục đến sở làm phù hợp nhất mà không bị nhàm chán.</P>
                    </div>
                    <div class="custom">
                        <h3>VỀ KHÁCH HÀNG</h3>
                        <P>Chú trọng đến không gian mua sắm, dịch vụ chăm sóc khách hàng, chế độ bảo hành, K&K Fashion
                            luôn cố gắng để trở thành người bạn thân thiết của khách hàng, lắng nghe những chia sẻ về
                            sản phẩm để tiếp tục cho ra những sản phẩm tốt hơn khiến người mặc hài lòng nhất.</P>
                    </div>
                </div>
                <div class="menu-rotate2">
                    <a href="">SHOWROOM</a>
                    <span></span>
                </div>
            </div>

        </div>

    </div>