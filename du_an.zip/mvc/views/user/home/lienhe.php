
        <div class="map">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3723.926138497063!2d105.79069011486902!3d21.03564118599462!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab5f095b1075%3A0xbbdf86dd0bc975f7!2zU2hvcCDEkeG7mWM!5e0!3m2!1svi!2s!4v1631282354307!5m2!1svi!2s"
                width="1900" height="550" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
        <div class="contact">
            <div class="cloumn-contact">
                <h2 class="title-content">
                    LIÊN HỆ
                </h2>
                <div class="menu_contact">
                    <ul>
                        <li>Điện thoại: (028) 36.222.999 - Hotline: (028) 36.222.999</li>
                        <li> Email: sales@kkfashion.vn</li>
                        <li>Website: www.kkfashion.vn</li>
                        <li> Fanpage: https://facebook.com/kkfashion.vn</li>
                    </ul>
                </div>
                <h3><i class="fab fa-facebook"></i>
                    <i class="fab fa-facebook-messenger"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                </h3>
            </div>
            <div>
                <h3>Liên hệ với chúng tôi</h3>
                <form action="">
                    <input style="padding: 15px 400px 15px 10px;margin-bottom: 20px;" type="number"
                        placeholder="Số điện thoại">
                    <br>
                    <input style="padding: 15px 400px 15px 10px;margin-bottom: 20px;" type="email" placeholder="email">
                    <br>
                    <input style="padding: 30px 400px 30px 10px;margin-bottom: 20px;" type="text"
                        placeholder="chúng tôi có thể giúp gì được cho bạn?">
                    <br>
                    <input type="submit" value="Gửi"  style=" text-align: center;padding: 13px 280px 13px 275px;margin-bottom: 100px; background: black; color: whitesmoke;">

                </form>
            </div>
        </div>
    </div>