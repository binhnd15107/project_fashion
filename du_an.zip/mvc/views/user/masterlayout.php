<?php include ('include/header.php') ; ?>
<?php require_once "./mvc/views/user/".$data['pages'].".php"; ?>
<?php include('include/footer.php') ;?>

    