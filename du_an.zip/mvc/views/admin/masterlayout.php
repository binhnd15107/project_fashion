<?php include ('include/header.php') ;?>
<?php require "./mvc/views/admin/".$data['pages'].".php"; ?>
<?php include ('include/footer.php') ?>