<?php 
require_once './mvc/core/App.php';
require_once './mvc/core/controller.php';
require_once './mvc/core/DB.php';
?>